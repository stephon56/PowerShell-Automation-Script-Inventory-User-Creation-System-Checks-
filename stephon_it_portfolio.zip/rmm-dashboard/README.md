# RMM Dashboard Mockup

## Author
**Stephon Villafana**

## Overview
A simple HTML/JS interface that simulates an RMM system’s device monitoring view:
- Displays system status (Online/Offline)
- Shows CPU and RAM usage
- Built to demonstrate UI understanding of monitoring tools
