# Stephon Villafana | IT Support & Automation Portfolio

## Job Title / Tagline
IT Support Specialist | Network & Systems Admin | PowerShell Automation

## Overview
This GitHub portfolio demonstrates practical IT skills:
- **PowerShell Automation:** Scripts for inventory, user creation, system health checks
- **RMM Dashboard:** Simple mockup to simulate device monitoring
- **Documentation:** Professional SOP for Windows OS migration

## Contact
- GitHub: [Your GitHub URL]
- LinkedIn: [Your LinkedIn URL]
