# PowerShell Automation Scripts

## Author
**Stephon Villafana**

## Overview
This collection automates basic IT admin tasks:
- System inventory
- User creation
- System health checks

## Usage
- Open PowerShell as Administrator
- Run the scripts individually
- Output files are saved in the script directory
